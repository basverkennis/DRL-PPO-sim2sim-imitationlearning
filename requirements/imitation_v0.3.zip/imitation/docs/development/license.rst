.. _License:

License
=======

This license is also available on the `project repository <https://github.com/HumanCompatibleAI/imitation/blob/master/LICENSE>`_.

.. include:: ../../LICENSE
