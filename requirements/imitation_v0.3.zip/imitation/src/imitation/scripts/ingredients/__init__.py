"""Ingredients for scripts."""
