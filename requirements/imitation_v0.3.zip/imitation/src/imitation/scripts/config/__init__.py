"""Configuration settings for scripts."""
