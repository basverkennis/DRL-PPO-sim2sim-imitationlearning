"""Helper methods for unit tests.

May also be useful for users of imitation.
"""
