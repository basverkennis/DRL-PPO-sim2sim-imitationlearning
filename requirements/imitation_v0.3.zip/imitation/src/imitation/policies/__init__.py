"""Classes defining policies and methods to manipulate them (e.g. serialization)."""
